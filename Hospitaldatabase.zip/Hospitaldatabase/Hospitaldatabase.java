/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
import java.util.InputMismatchException;
public class Hospitaldatabase {
 private final PatientService service;
 private final Scanner scanner;
Hospitaldatabase object.
 public Hospitaldatabase() {
 this.service = new PatientService();
 this.scanner = new Scanner(System.in);
 }
 public static void main(String[] args) {
 Hospitaldatabase app = new Hospitaldatabase();
 app.runMenu();
 }
 // The main application loop
 public void runMenu() {
 boolean running = true;
 
 'while(true)' loop
 do {
 printMenu();
 int choice = getUserChoice();
 switch (choice) {
 case 1:
 handlePatientAdd();
 break;
 case 2:
 service.viewAllPatients(); 
 break;
 case 3:
 handlePatientUpdate();
 break;
 case 4:
 handlePatientDelete();
 break;
 case 5:
 running = false; end
 break;
 default:
 System.out.println("Invalid input. Please enter a number from 1 to 5.");
 }
 } while (running);
 System.out.println("Exiting Hospital Management System. Goodbye.");
 scanner.close(); 
 }
 private void printMenu() {
 System.out.println("\n--- Hospital Patient Menu ---");
 System.out.println("1. Register New Patient");
 System.out.println("2. View All Patient Records");
 System.out.println("3. Modify Patient Record");
 System.out.println("4. Remove Patient Record");
 System.out.println("5. Exit Application");
 System.out.print("Please select an option: ");
 }
 private int getUserChoice() {
 try {
 return Integer.parseInt(scanner.nextLine());
 } catch (NumberFormatException e) {
 return -1; 
 }
 }
 private void handlePatientAdd() {
 System.out.print("Enter Full Name: ");
 String name = scanner.nextLine();
 System.out.print("Enter Date of Birth (YYYY-MM-DD): ");
 String dob = scanner.nextLine();
 System.out.print("Enter Full Address: ");
 String address = scanner.nextLine();
 
 service.addPatient(name, dob, address);
 }
 private void handlePatientUpdate() {
 try {
 System.out.print("Enter the ID of the patient to update: ");
 int id = Integer.parseInt(scanner.nextLine());
 System.out.print("Enter new Full Name: ");
 String name = scanner.nextLine();
 System.out.print("Enter new Date of Birth (YYYY-MM-DD): ");
 String dob = scanner.nextLine();
 System.out.print("Enter new Full Address: ");
 String address = scanner.nextLine();
 
 service.updatePatient(id, name, dob, address);
 } catch (NumberFormatException e) {
 System.out.println("Invalid ID. Please enter a number.");
 }
 }
 private void handlePatientDelete() {
 try {
 System.out.print("Enter the ID of the patient to delete: ");
 int id = Integer.parseInt(scanner.nextLine());
 
 service.deletePatient(id);
 } catch (NumberFormatException e) {
 System.out.println("Invalid ID. Please enter a number.");
 }
 }
 }