/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentmanagementsystem;

import java.util.ArrayList;
import java.util.Scanner;
import studentmanagementsystem.StudentInfo;

/**
 *
 * @author Sinethemba Mncina
 */

public class StudentManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<StudentInfo> students = new ArrayList();
        

                Scanner scanner = new Scanner(System.in);
                
                while (true)
                { 
                    System.out.println("STudent Management System Menus:");
                System.out.println("1.Add Students");
                System.out.println("2.Display Students");
                System.out.println("3.Search Student");
                System.out.println("4.Remove Students");
                System.out.println("5.Update Student");
                System.out.println("6.Exit");
int Choice = scanner.nextInt();
scanner.nextLine();

Choice =scanner.nextInt(Choice);
        switch (Choice) {
    case 1:System.out.print("Enter Student name:");
    String name = scanner.nextLine();
    System.out.print("Enter Student ID:");
    String ID = scanner.nextLine();
    StudentInfo newStudent = new StudentInfo(name,id,age);
            Students.add(newStudent);
            System.out.println("Student added successfully!");
    int age = scanner.nextInt();
            scanner.nextLine();
        break;
    case 2:
        System.out.println("Student list");
for (StudentInfo student : students){
    System.out.println("Name:" + student.getName()+ ",ID: " + student.getId() + ", Age:"+ Student.getAge());
}

        break;
        case 3:System.out.print("Enter ID of Student to Search:");
        String searhid = scanner .nextLine();
        Boolean foubd = false;
        for (StudentInfo studenr: students){
            if (student.getId().equals(searchid)){
                System.out.println("Student Found:");
                System.out.println("Name:"= Student.getrName()+",ID:")+student.getid()+ ",Age:";+student.getAge());
                Found = true
                 Break;       
            }
        }
        if (!found){
            System.out.println("Student with ID "+searchid + "nout found");
        }
        break;
    case 4:
        break;
        case 5:
        break;
    case 6:
        System.out.println("Exiting");
        return;
        System.out.println(invalid input. Please Try Again);
}
              
                }
        // TODO code application logic here
    }
    
}
