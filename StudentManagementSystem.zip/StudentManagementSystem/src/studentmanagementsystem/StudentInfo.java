/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentmanagementsystem;

/**
 *
 * @author Sinethemba Mncina
 */
public class StudentInfo {
    private int StudentID;
    private String name;
    private int age; // student records //


 public StudentInfo(String name,String id, int, age);

}
